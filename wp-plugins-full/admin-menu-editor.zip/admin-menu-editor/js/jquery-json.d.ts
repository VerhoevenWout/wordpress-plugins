interface JQueryStatic {
	//This method is added by the jquery-json plugin.
	toJSON: (data: any) => string;
}