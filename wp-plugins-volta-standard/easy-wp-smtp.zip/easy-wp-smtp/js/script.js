(function ($) {
	$(document).ready(function () {
		/*
		 *add notice about changing in the settings page
		 */

	});
})(jQuery);
